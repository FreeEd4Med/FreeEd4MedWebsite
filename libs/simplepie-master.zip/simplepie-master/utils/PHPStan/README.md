# SimplePie PHPStan extension

**This extension is considered unstable, use at your own risk.**

It provides:

- Correct return type for `Registry::call()`
